const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('disk', {
  load: () => ipcRenderer.sendSync('veri-oku'),
  save: (txt) => ipcRenderer.sendSync('veri-yaz', txt),
  delta: (d) => ipcRenderer.sendSync('veri-degisim', d),
  flags: () => ipcRenderer.sendSync('bayrak'),
  loginOk: (id) => ipcRenderer.sendSync('giris-tamam', id),
  logout: () => ipcRenderer.sendSync('cikis'),
  theme: () => ipcRenderer.sendSync('tema-oku'),
  refocus: () => ipcRenderer.sendSync('odak'),
  pick: (tur) => ipcRenderer.invoke('dosya-sec', tur),
  onMenu: (cb) => ipcRenderer.on('menu', (_e, a) => cb(a))
});
