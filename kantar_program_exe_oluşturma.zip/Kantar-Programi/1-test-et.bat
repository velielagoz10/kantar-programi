@echo off
cd /d "%~dp0"
echo Gerekli dosyalar yukleniyor (ilk seferde birkac dakika surer)...
call npm install
echo.
echo Program aciliyor...
call npm start
pause
