@echo off
cd /d "%~dp0"
echo Gerekli dosyalar yukleniyor...
call npm install
echo.
echo Kurulum dosyasi olusturuluyor (birkac dakika surer)...
call npm run build
echo.
echo BITTI. Kurulum dosyasi "dist" klasorunde: Kantar-Programi-Setup-1.6.1.exe + latest.yml
pause
