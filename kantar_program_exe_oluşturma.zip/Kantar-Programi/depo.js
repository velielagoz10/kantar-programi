'use strict';
// Kantar Programı veri katmanı — SQLite (Electron'a yerleşik "node:sqlite", ek paket gerekmez)
const SCHEMA = `
CREATE TABLE IF NOT EXISTS ayar(k TEXT PRIMARY KEY, v TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, u TEXT, s TEXT, h TEXT, role TEXT, created TEXT, def INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS firmalar(sira INTEGER, ad TEXT PRIMARY KEY);
CREATE TABLE IF NOT EXISTS malzemeler(sira INTEGER, ad TEXT PRIMARY KEY, fiyat REAL);
CREATE TABLE IF NOT EXISTS araclar(plaka TEXT PRIMARY KEY, dorse TEXT, sofor TEXT, tc TEXT, tel TEXT, firma TEXT, malzeme TEXT, ek TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS iceride(plaka TEXT PRIMARY KEY, dorse TEXT, sofor TEXT, tc TEXT, tel TEXT, firma TEXT, malzeme TEXT, aciklama TEXT, t1 INTEGER, g_tarih TEXT, g_saat TEXT, ek TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS rapor(no INTEGER PRIMARY KEY, plaka TEXT, dorse TEXT, sofor TEXT, tc TEXT, tel TEXT, firma TEXT, malzeme TEXT, aciklama TEXT, t1 INTEGER, t2 INTEGER, net INTEGER, g_tarih TEXT, g_saat TEXT, c_tarih TEXT, c_saat TEXT, durum TEXT, ek TEXT DEFAULT '');
CREATE INDEX IF NOT EXISTS ix_rapor_ctarih ON rapor(c_tarih);
CREATE INDEX IF NOT EXISTS ix_rapor_plaka ON rapor(plaka);
`;
function hazir() { try { return typeof require('node:sqlite').DatabaseSync === 'function'; } catch (e) { return false; } }
const T = v => (v === undefined || v === null) ? '' : String(v);
// Kullanıcının eklediği bilgi alanları sabit sütunlara sığmaz: "ek" sütununda JSON olarak tutulur
const BILINEN = {
  araclar: ['plaka', 'dorse', 'sofor', 'tc', 'tel', 'firma', 'malzeme'],
  iceride: ['plaka', 'dorse', 'sofor', 'tc', 'tel', 'firma', 'malzeme', 'aciklama', 't1', 'gTarih', 'gSaat'],
  rapor: ['no', 'plaka', 'dorse', 'sofor', 'tc', 'tel', 'firma', 'malzeme', 'aciklama', 't1', 't2', 'net', 'gTarih', 'gSaat', 'cTarih', 'cSaat', 'durum']
};
const EK = (r, tablo) => { const o = {}, b = BILINEN[tablo]; for (const k of Object.keys(r || {})) if (!b.includes(k) && r[k] !== undefined && r[k] !== null && r[k] !== '') o[k] = r[k]; return Object.keys(o).length ? JSON.stringify(o) : ''; };
const EKOKU = ek => { try { const o = ek ? JSON.parse(ek) : {}; return (o && typeof o === 'object') ? o : {}; } catch (e) { return {}; } };
const I = v => { const n = Number(v); return Number.isFinite(n) ? Math.round(n) : 0; };

class Depo {
  constructor(dosya) {
    const { DatabaseSync } = require('node:sqlite');
    this.db = new DatabaseSync(dosya);
    this.db.exec('PRAGMA journal_mode=DELETE; PRAGMA synchronous=FULL;');   // elektrik kesilse de kayıt bozulmaz
    this.db.exec(SCHEMA);
    for (const t of ['araclar', 'iceride', 'rapor'])   // eski veritabanını güncelle (mevcut kayıtlar aynen kalır)
      if (!this.db.prepare('PRAGMA table_info(' + t + ')').all().some(x => x.name === 'ek')) this.db.exec('ALTER TABLE ' + t + " ADD COLUMN ek TEXT DEFAULT ''");
    const d = this.db, p = s => d.prepare(s);
    this.q = {
      ayar: p('INSERT OR REPLACE INTO ayar(k,v) VALUES(?,?)'),
      user: p('INSERT OR REPLACE INTO users(id,u,s,h,role,created,def) VALUES(?,?,?,?,?,?,?)'),
      firma: p('INSERT OR REPLACE INTO firmalar(sira,ad) VALUES(?,?)'),
      malz: p('INSERT OR REPLACE INTO malzemeler(sira,ad,fiyat) VALUES(?,?,?)'),
      arac: p('INSERT OR REPLACE INTO araclar(plaka,dorse,sofor,tc,tel,firma,malzeme,ek) VALUES(?,?,?,?,?,?,?,?)'),
      ice: p('INSERT OR REPLACE INTO iceride(plaka,dorse,sofor,tc,tel,firma,malzeme,aciklama,t1,g_tarih,g_saat,ek) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)'),
      rsil: p('DELETE FROM rapor WHERE no=?'),
      rap: p('INSERT OR REPLACE INTO rapor(no,plaka,dorse,sofor,tc,tel,firma,malzeme,aciklama,t1,t2,net,g_tarih,g_saat,c_tarih,c_saat,durum,ek) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
    };
  }
  tx(fn) {
    this.db.exec('BEGIN IMMEDIATE');
    try { const r = fn(); this.db.exec('COMMIT'); return r; }
    catch (e) { try { this.db.exec('ROLLBACK'); } catch (x) { } throw e; }
  }
  kontrol() {
    const r = this.db.prepare('PRAGMA quick_check').all();
    if (!(r.length === 1 && Object.values(r[0])[0] === 'ok')) return false;
    const t = this.db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map(x => x.name);
    return ['ayar', 'users', 'araclar', 'iceride', 'rapor'].every(n => t.includes(n));
  }
  say(t) { return Number(this.db.prepare('SELECT COUNT(*) n FROM ' + t).get().n); }
  // Tüm veriyi uygulamanın kullandığı biçimde döndürür; veritabanı yeniyse null
  oku() {
    if (!['users', 'rapor', 'araclar', 'malzemeler', 'firmalar', 'ayar'].some(t => this.say(t))) return null;
    const a = s => this.db.prepare(s).all(), D = { ayar: {}, fiyat: {} };
    for (const r of a('SELECT k,v FROM ayar')) D.ayar[r.k] = JSON.parse(r.v);
    D.users = a('SELECT id,u,s,h,role,created,def FROM users').map(r => ({ ...r, def: !!r.def }));
    D.firmalar = a('SELECT ad FROM firmalar ORDER BY sira').map(r => r.ad);
    D.malzemeler = a('SELECT ad,fiyat FROM malzemeler ORDER BY sira').map(r => { if (r.fiyat !== null) D.fiyat[r.ad] = r.fiyat; return r.ad; });
    const ekle = r => { const { ek, ...o } = r; return { ...EKOKU(ek), ...o }; };
    D.araclar = a('SELECT plaka,dorse,sofor,tc,tel,firma,malzeme,ek FROM araclar ORDER BY rowid').map(ekle);
    D.iceride = a('SELECT plaka,dorse,sofor,tc,tel,firma,malzeme,aciklama,t1,g_tarih gTarih,g_saat gSaat,ek FROM iceride ORDER BY rowid').map(ekle);
    D.rapor = a('SELECT no,plaka,dorse,sofor,tc,tel,firma,malzeme,aciklama,t1,t2,net,g_tarih gTarih,g_saat gSaat,c_tarih cTarih,c_saat cSaat,durum,ek FROM rapor ORDER BY no').map(ekle);
    return D;
  }
  _rap(r) { this.q.rap.run(I(r.no), T(r.plaka), T(r.dorse), T(r.sofor), T(r.tc), T(r.tel), T(r.firma), T(r.malzeme), T(r.aciklama), I(r.t1), I(r.t2), I(r.net), T(r.gTarih), T(r.gSaat), T(r.cTarih), T(r.cSaat), T(r.durum), EK(r, 'rapor')); }
  // Küçük tablolar (araçlar, tanımlar, kullanıcılar, ayarlar) baştan yazılır; raporlar yalnızca eklenir
  _kucuk(d) {
    this.db.exec('DELETE FROM araclar; DELETE FROM iceride; DELETE FROM firmalar; DELETE FROM malzemeler; DELETE FROM users; DELETE FROM ayar;');
    for (const k of Object.keys(d.ayar || {})) this.q.ayar.run(k, JSON.stringify(d.ayar[k]));
    for (const u of d.users || []) this.q.user.run(T(u.id), T(u.u), T(u.s), T(u.h), T(u.role), T(u.created), u.def ? 1 : 0);
    (d.firmalar || []).forEach((x, i) => this.q.firma.run(i, T(x)));
    (d.malzemeler || []).forEach((x, i) => { const f = (d.fiyat || {})[x]; this.q.malz.run(i, T(x), f === undefined || f === null ? null : Number(f)); });
    for (const r of d.araclar || []) this.q.arac.run(T(r.plaka), T(r.dorse), T(r.sofor), T(r.tc), T(r.tel), T(r.firma), T(r.malzeme), EK(r, 'araclar'));
    for (const r of d.iceride || []) this.q.ice.run(T(r.plaka), T(r.dorse), T(r.sofor), T(r.tc), T(r.tel), T(r.firma), T(r.malzeme), T(r.aciklama), I(r.t1), T(r.gTarih), T(r.gSaat), EK(r, 'iceride'));
  }
  // raporYeni: yeni VE güncellenen kayıtlar (no aynıysa üzerine yazılır); raporSil: silinen kayıt numaraları
  degisim(d) { this.tx(() => { this._kucuk(d); for (const n of d.raporSil || []) this.q.rsil.run(I(n)); for (const r of d.raporYeni || []) this._rap(r); }); }
  yaz(D) { this.tx(() => { this.db.exec('DELETE FROM rapor;'); this._kucuk(D); for (const r of D.rapor || []) this._rap(r); }); }
  kapat() { try { this.db.close(); } catch (e) { } }
}
module.exports = { Depo, hazir };
