const { app, BrowserWindow, ipcMain, shell, Menu, dialog, screen } = require('electron');
const path = require('path'), fs = require('fs');

// Veriler: Belgelerim\Kantar-Programi\veri.db  (program silinse bile kalır)
const KLASOR = path.join(app.getPath('documents'), 'Kantar-Programi');
const DB = path.join(KLASOR, 'veri.db'), PENCERE = path.join(KLASOR, 'pencere.json'), AYAR = path.join(KLASOR, 'ayar.json');
let depo = null, BILDIRIM = null, SIFIRLA = false;
const p2 = n => String(n).padStart(2, '0');
const zaman = () => { const d = new Date(); return `${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}-${p2(d.getHours())}${p2(d.getMinutes())}${p2(d.getSeconds())}`; };
const bildir = m => { BILDIRIM = BILDIRIM ? BILDIRIM + '\n\n' + m : m; };
const gecerli = d => !!d && ['rapor', 'araclar', 'iceride', 'firmalar', 'malzemeler', 'users'].every(k => Array.isArray(d[k])) && d.users.length > 0;

function veritabani() {
  const { Depo, hazir } = require('./depo.js');
  if (!hazir()) throw new Error('Bu bilgisayarda SQLite desteklenmiyor (Windows 10/11 gerekir).');
  fs.mkdirSync(KLASOR, { recursive: true });
  if (fs.existsSync(DB)) {
    try { depo = new Depo(DB); if (!depo.kontrol()) throw new Error('kontrol'); return; }
    catch (e) {
      try { depo && depo.kapat(); } catch (x) { } depo = null;
      const ad = 'bozuk-veri-' + zaman() + '.db';
      fs.renameSync(DB, path.join(KLASOR, ad));
      bildir(`Veritabanı dosyası bozulmuş. Dosya "Belgelerim\\Kantar-Programi\\${ad}" adıyla saklandı ve program boş başlatıldı.\nElinizde yedek varsa Dosya > Yedek Yükle ile geri yükleyebilirsiniz.`);
    }
  }
  depo = new Depo(DB);
}

ipcMain.on('veri-oku', e => {
  try { const d = depo.oku(); e.returnValue = d ? JSON.stringify(d) : null; }
  catch (err) { dialog.showErrorBox('Veri okunamadı', 'Veritabanı okunamadı: ' + (err.message || err) + '\n\nVerileriniz silinmedi. Belgelerim\\Kantar-Programi klasörünü kopyalayıp destek isteyin.'); app.exit(1); e.returnValue = null; }
});
ipcMain.on('veri-yaz', (e, t) => { try { const d = JSON.parse(t); if (!gecerli(d)) throw new Error('geçersiz'); depo.yaz(d); e.returnValue = true; } catch (x) { e.returnValue = false; } });
ipcMain.on('veri-degisim', (e, d) => { try { depo.degisim(d); e.returnValue = true; } catch (x) { e.returnValue = false; } });
ipcMain.on('bayrak', e => { e.returnValue = { bildirim: BILDIRIM, sifirla: SIFIRLA }; BILDIRIM = null; SIFIRLA = false; });
// Giriş başarılı: önce ana pencere açılır, sonra giriş penceresi kapanır (pencere kalmazsa program kapanır)
ipcMain.on('giris-tamam', (e, uid) => { const eski = BrowserWindow.fromWebContents(e.sender); anaPencere(uid); try { eski && eski.close(); } catch (x) { } e.returnValue = true; });
// Çıkış / oturum kapatma: önce giriş penceresi açılır, sonra ana pencere kapanır
ipcMain.on('cikis', e => { const eski = BrowserWindow.fromWebContents(e.sender); girisPencere(); try { eski && eski.close(); } catch (x) { } e.returnValue = true; });
// Yazdırma / diyalog penceresi kapandıktan sonra imleç (el işareti) takılı kalabiliyor.
// Pencereye odak verip, fare imlecinin bulunduğu yere sahte fare hareketi göndererek imleci yeniden hesaplatırız.
function imlecTazele(w) {
  if (!w || w.isDestroyed()) return;
  const dokun = () => {
    try {
      if (w.isDestroyed()) return;
      const p = screen.getCursorScreenPoint(), b = w.getContentBounds(), cx = p.x - b.x, cy = p.y - b.y;
      if (cx < 1 || cy < 1 || cx >= b.width - 1 || cy >= b.height - 1) return;
      w.webContents.sendInputEvent({ type: 'mouseMove', x: cx + 1, y: cy });
      w.webContents.sendInputEvent({ type: 'mouseMove', x: cx, y: cy });
    } catch (err) { }
  };
  try { w.blur(); w.focus(); w.webContents.focus(); } catch (err) { }
  dokun(); [100, 300, 700, 1500].forEach(t => setTimeout(dokun, t));
}
ipcMain.on('odak', e => { try { imlecTazele(BrowserWindow.fromWebContents(e.sender)); } catch (x) { } e.returnValue = true; });
// Menüden tetiklenen "içe aktar" işlemlerinde sayfa içi dosya seçici açılamaz (kullanıcı tıklaması sayılmaz); seçimi burada yaparız
ipcMain.handle('dosya-sec', async (e, tur) => {
  const w = BrowserWindow.fromWebContents(e.sender);
  const json = tur === 'json';
  try {
    const r = await dialog.showOpenDialog(w, { title: json ? 'Yedek dosyasını seçin' : 'Excel dosyasını seçin', properties: ['openFile'],
      filters: [json ? { name: 'Yedek dosyası (JSON)', extensions: ['json'] } : { name: 'Excel dosyası (xlsx)', extensions: ['xlsx'] }] });
    imlecTazele(w);
    if (r.canceled || !r.filePaths.length) return null;
    return { ad: path.basename(r.filePaths[0]), b64: fs.readFileSync(r.filePaths[0]).toString('base64') };
  } catch (x) { return null; }
});

// Görünüm teması (açık / karanlık): Belgelerim\Kantar-Programi\ayar.json içinde saklanır
function temaOku() { try { return JSON.parse(fs.readFileSync(AYAR, 'utf8')).tema === 'dark' ? 'dark' : 'light'; } catch (e) { return 'light'; } }
function temaYaz(t) { try { fs.mkdirSync(KLASOR, { recursive: true }); fs.writeFileSync(AYAR, JSON.stringify({ tema: t === 'dark' ? 'dark' : 'light' })); } catch (e) { } }
ipcMain.on('tema-oku', e => { e.returnValue = temaOku(); });

function pencereDurumu() {
  try {
    const d = JSON.parse(fs.readFileSync(PENCERE, 'utf8'));
    const ok = [d.x, d.y, d.width, d.height].every(Number.isFinite) && d.width >= 900 && d.height >= 600 &&
      screen.getAllDisplays().some(s => { const a = s.workArea; return d.x < a.x + a.width - 100 && d.x + d.width > a.x + 100 && d.y < a.y + a.height - 100 && d.y + d.height > a.y + 50; });
    return { max: !!d.max, bounds: ok ? { x: d.x, y: d.y, width: d.width, height: d.height } : null };
  } catch (e) { return null; }
}

// ---- Güncelleme: Yardım > Güncellemeleri Denetle (kurulum dosyası GitHub Releases'te durur) ----
let guncelleniyor = false, guncelleyici = null;
async function guncellemeDenetle(w) {
  if (guncelleniyor) return;
  guncelleniyor = true;
  const mesaj = (type, message, detail, buttons = ['Tamam']) => dialog.showMessageBox(w, { type, title: 'Güncelleme', message, detail, buttons, defaultId: 0, cancelId: buttons.length - 1, noLink: true });
  try {
    if (!app.isPackaged) { await mesaj('info', 'Güncelleme yalnızca kurulu programda çalışır.', 'Şu an test sürümünü (1-test-et) kullanıyorsunuz.'); return; }
    if (!guncelleyici) {
      guncelleyici = require('electron-updater').autoUpdater;
      guncelleyici.autoDownload = false;
      guncelleyici.autoInstallOnAppQuit = false;
    }
    const u = guncelleyici;
    const r = await u.checkForUpdates();
    const yeni = r && r.updateInfo && r.updateInfo.version;
    if (!r || !r.isUpdateAvailable || !yeni) { await mesaj('info', 'Program güncel.', `Kurulu sürüm (${app.getVersion()}) en son sürümdür.`); return; }
    const c = await mesaj('question', `Yeni sürüm var: ${yeni}`, `Kurulu sürüm: ${app.getVersion()}\n\nŞimdi indirilip kurulsun mu? Verileriniz (Belgelerim\\Kantar-Programi) olduğu gibi kalır.`, ['İndir ve Kur', 'Sonra']);
    if (c.response !== 0) return;
    u.removeAllListeners('download-progress');
    u.on('download-progress', pr => { try { w.setProgressBar(Math.max(0, Math.min(1, pr.percent / 100))); } catch (e) { } });
    await u.downloadUpdate();
    try { w.setProgressBar(-1); } catch (e) { }
    const k = await mesaj('question', 'Güncelleme indirildi.', 'Program kapanıp güncellenecek ve kendiliğinden yeniden açılacak.', ['Şimdi Kur', 'Sonra']);
    if (k.response === 0) { u.quitAndInstall(true, true); return; }
    u.autoInstallOnAppQuit = true;   // "Sonra" denirse, program bir sonraki kapanışta kendiliğinden kurulur
  } catch (err) {
    try { await mesaj('error', 'Güncelleme yapılamadı.', 'İnternet bağlantınızı kontrol edip tekrar deneyin.\n\n' + String((err && err.message) || err).slice(0, 300)); } catch (e) { }
  } finally {
    guncelleniyor = false;
    try { w.setProgressBar(-1); } catch (e) { }
    imlecTazele(w);
  }
}

function menuKur(w) {
  const g = a => { try { w.webContents.send('menu', a); } catch (e) { } };
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    { label: 'Dosya', submenu: [
      { label: "Raporu Excel'e Aktar", click: () => g('excel') }, { type: 'separator' },
      { label: 'Yedek İndir…', click: () => g('yedek-indir') }, { label: 'Yedek Yükle…', click: () => g('yedek-yukle') },
      { label: 'Veri Klasörünü Aç', click: () => { try { fs.mkdirSync(KLASOR, { recursive: true }); } catch (e) { } shell.openPath(KLASOR); } },
      { type: 'separator' }, { label: 'Çıkış', click: () => app.quit() }] },
    { label: 'Düzen', submenu: [
      { role: 'undo', label: 'Geri Al' }, { role: 'redo', label: 'Yinele' }, { type: 'separator' },
      { role: 'cut', label: 'Kes' }, { role: 'copy', label: 'Kopyala' }, { role: 'paste', label: 'Yapıştır' }, { role: 'selectAll', label: 'Tümünü Seç' },
      { type: 'separator' }, { label: 'Raporlarda Ara', accelerator: 'CommandOrControl+F', click: () => g('ara') }] },
    { label: 'Görünüm', submenu: [
      { label: 'Ana Ekran', accelerator: 'CommandOrControl+1', click: () => g('git:ana') },
      { label: 'Raporlar', accelerator: 'CommandOrControl+2', click: () => g('git:rapor') },
      { label: 'Tanımlı Araçlar', accelerator: 'CommandOrControl+3', click: () => g('git:arac') },
      { label: 'Tanımlar', accelerator: 'CommandOrControl+4', click: () => g('git:tanim') },
      { label: 'Özet', accelerator: 'CommandOrControl+5', click: () => g('git:ozet') },
      { type: 'separator' }, { label: 'Karanlık Mod', type: 'checkbox', checked: temaOku() === 'dark', accelerator: 'CommandOrControl+Shift+D',
        click: it => { const t = it.checked ? 'dark' : 'light'; temaYaz(t); g('tema:' + t); } },
      { type: 'separator' }, { role: 'zoomIn', label: 'Yakınlaştır' }, { role: 'zoomOut', label: 'Uzaklaştır' }, { role: 'resetZoom', label: 'Normal Boyut' },
      { type: 'separator' }, { role: 'togglefullscreen', label: 'Tam Ekran' },
      ...(app.isPackaged ? [] : [{ type: 'separator' }, { role: 'toggleDevTools', label: 'Geliştirici Araçları' }])] },
    { label: 'Ayarlar', submenu: [
      { label: 'Firma ve Fiş Ayarları…', click: () => g('git:ayar') }, { label: 'Kullanıcılar…', click: () => g('git:kull') }] },
    { label: 'Veri', submenu: [
      { label: 'Tüm Verileri Dışa Aktar (Excel)…', click: () => g('veri-xlsx') },
      { label: 'Tüm Verileri İçe Aktar (Excel)…', click: () => g('veri-xlsx-ice') }, { type: 'separator' },
      { label: 'Tam Yedek İndir (JSON)…', click: () => g('yedek-indir') }, { label: 'Tam Yedek Yükle (JSON)…', click: () => g('yedek-yukle') }] },
    { label: 'Yardım', submenu: [{ label: 'Güncellemeleri Denetle…', click: () => guncellemeDenetle(w) }, { type: 'separator' }, { label: 'Hakkında', click: () => {
      dialog.showMessageBox(w, { type: 'info', title: 'Hakkında', message: 'Kantar Programı', detail: `Geliştirici: Veli Elagöz\nSürüm: ${app.getVersion()}\nVeri: SQLite veritabanı\nVeri klasörü: ${KLASOR}`, buttons: ['Tamam'], noLink: true })
        .then(() => imlecTazele(w)).catch(() => { });
    } }] }
  ]));
}

// Giriş penceresi: küçük, büyütülemez, menüsüz. Giriş başarılı olunca kapanır ve ana pencere açılır.
function girisPencere() {
  Menu.setApplicationMenu(null);
  // Küçük ekranlarda pencere çalışma alanına sığacak şekilde küçülür (içerik de sayfada otomatik küçülür)
  const wa = screen.getDisplayNearestPoint(screen.getCursorScreenPoint()).workAreaSize;
  const gw = Math.max(300, Math.min(440, wa.width - 40)), gh = Math.max(300, Math.min(440, wa.height - 90));
  const w = new BrowserWindow({ width: gw, height: gh, useContentSize: true, show: false, title: 'Kantar Programı - Giriş', backgroundColor: temaOku() === 'dark' ? '#141922' : '#f1f5fa',
    resizable: false, maximizable: false, fullscreenable: false, center: true, autoHideMenuBar: true,
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, spellcheck: false, devTools: !app.isPackaged } });
  try { w.removeMenu(); } catch (e) { }
  let ok = false; const goster = () => { if (ok) return; ok = true; w.show(); w.focus(); };
  let hz = 0; const hazir = () => { if (++hz >= 2) goster(); };
  w.once('ready-to-show', hazir); w.webContents.once('did-finish-load', hazir); setTimeout(goster, 4000);
  w.loadFile('index.html', { query: { mod: 'giris' } });
  w.on('page-title-updated', ev => ev.preventDefault());
  w.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  w.webContents.on('will-navigate', ev => ev.preventDefault());
  w.webContents.on('context-menu', (ev, p) => {
    if (!p.isEditable && !p.selectionText) return; const f = p.editFlags || {};
    Menu.buildFromTemplate([{ role: 'cut', label: 'Kes', enabled: !!f.canCut }, { role: 'copy', label: 'Kopyala', enabled: !!f.canCopy }, { role: 'paste', label: 'Yapıştır', enabled: !!f.canPaste }]).popup({ window: w });
  });
}

function anaPencere(uid) {
  const durum = pencereDurumu();
  const o = { width: 1400, height: 850, minWidth: 1000, minHeight: 650, show: false, title: 'Kantar Programı', backgroundColor: temaOku() === 'dark' ? '#141922' : '#eef1f6',
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, spellcheck: false, devTools: !app.isPackaged } };
  if (durum && durum.bounds) Object.assign(o, durum.bounds);
  const w = new BrowserWindow(o), buyut = true;   // her açılışta tam ekran (büyütülmüş pencere)
  let ok = false; const goster = () => { if (ok) return; ok = true; if (buyut) w.maximize(); w.show(); };
  let hz = 0; const hazir = () => { if (++hz >= 2) goster(); };
  w.once('ready-to-show', hazir); w.webContents.once('did-finish-load', hazir); setTimeout(goster, 6000);
  w.loadFile('index.html', { query: { mod: 'ana', u: String(uid || '') } });
  w.on('page-title-updated', ev => ev.preventDefault());
  try { w.webContents.setVisualZoomLevelLimits(1, 1); } catch (e) { }
  w.on('close', () => { try { const b = w.getNormalBounds(); fs.mkdirSync(KLASOR, { recursive: true }); fs.writeFileSync(PENCERE, JSON.stringify({ x: b.x, y: b.y, width: b.width, height: b.height, max: w.isMaximized() })); } catch (e) { } });
  w.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/i.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  w.webContents.on('will-navigate', (ev, url) => { ev.preventDefault(); if (/^https?:/i.test(url)) shell.openExternal(url); });
  w.webContents.on('context-menu', (ev, p) => {
    if (!p.isEditable && !p.selectionText) return; const f = p.editFlags || {};
    Menu.buildFromTemplate([{ role: 'cut', label: 'Kes', enabled: !!f.canCut }, { role: 'copy', label: 'Kopyala', enabled: !!f.canCopy }, { role: 'paste', label: 'Yapıştır', enabled: !!f.canPaste }, { type: 'separator' }, { role: 'selectAll', label: 'Tümünü Seç' }]).popup({ window: w });
  });
  menuKur(w);
}

function baslat() {
  try { fs.readdirSync(KLASOR).filter(f => /^sifre-sifirla/i.test(f)).forEach(f => { SIFIRLA = true; fs.unlinkSync(path.join(KLASOR, f)); }); } catch (e) { }
  try { veritabani(); } catch (e) { dialog.showErrorBox('Veritabanı açılamadı', String(e.message || e) + '\n\nVerileriniz silinmedi (Belgelerim\\Kantar-Programi).'); return app.exit(1); }
  girisPencere();
}
if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on('second-instance', () => { const w = BrowserWindow.getAllWindows()[0]; if (w) { if (w.isMinimized()) w.restore(); w.focus(); } });
  app.setAppUserModelId('com.kantar.programi');
  app.whenReady().then(baslat);
  app.on('will-quit', () => { try { depo && depo.kapat(); } catch (e) { } });
  app.on('window-all-closed', () => app.quit());
}
